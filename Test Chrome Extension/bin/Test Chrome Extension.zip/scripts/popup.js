console.log("Loaded the popup");
$(function () {
    chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
        pageUrl = tabs[0].url;
        pageTitle = tabs[0].title;
        faviconURL = tabs[0].favIconUrl;
        tabID = tabs[0].id;
        console.log("For tab id:" + tabID + " title=" + pageTitle + " url:" + pageUrl + " faviconURL:" + faviconURL);
        $('.pageTitleBox img').attr("src", faviconURL);
        $('#pageTitle').text(pageTitle);
    });
});