if (window.annotator) window.annotator.destroy();
delete window.annotator;
