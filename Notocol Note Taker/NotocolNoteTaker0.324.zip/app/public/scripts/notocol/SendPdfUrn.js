﻿//var urn;

//if (typeof PDFViewerApplication == "undefined")
//    urn = document.URL;
//else
//    urn = "urn:x-pdf-" + PDFViewerApplication.documentFingerprint;
    
//console.log("Sending URN: " + urn);
//window.postMessage({ type: "FROM_PAGE", text: "Hello from the webpage!", urn: urn }, "*");